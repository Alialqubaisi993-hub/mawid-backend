# مَوعِد — نظام حجز الصالونات

## هيكل المشروع
```
mawid-backend/     ← الباك إند (Node.js + Express)
mawid-frontend/    ← الفرونت إند (React)
```

---

## تشغيل الباك إند

```bash
cd mawid-backend
npm install
node server.js
```

الخادم يشتغل على: http://localhost:4000

---

## تشغيل الفرونت إند

```bash
cd mawid-frontend
npm install
npm start
```

الموقع يفتح على: http://localhost:3000

---

## بيانات الدخول التجريبية

| الدور | البريد | كلمة المرور |
|-------|--------|-------------|
| المدير | admin@mawid.app | admin123 |

---

## الأدوار والصلاحيات

### 🔑 المدير (admin)
- يشوف كل الصالونات المسجلة
- يفعّل أو يوقف أي صالون
- يرى الإحصائيات الكاملة

### 💼 صاحب الصالون (owner)
- يدير خدماته وأسعاره
- يعدّل أوقات المواعيد وأيام العمل
- ينسخ رابط الحجز ويرسله للزبائن
- يشوف المواعيد القادمة مع أرقام الزبائن

### 👤 الزبون (عام)
- يدخل رابط الحجز
- يختار خدمة، يوم، وقت
- يدخل اسمه ورقمه ويؤكد الحجز

---

## رابط الحجز للزبائن

```
http://localhost:3000/book/{slug-الصالون}
```

---

## API Endpoints

### Auth
- `POST /api/auth/login` — دخول
- `POST /api/auth/register` — تسجيل صالون جديد

### Admin (يحتاج توكن مدير)
- `GET /api/admin/saloons` — كل الصالونات
- `GET /api/admin/stats` — الإحصائيات
- `PATCH /api/admin/saloons/:id/status` — تغيير حالة صالون

### Owner (يحتاج توكن صاحب صالون)
- `GET /api/owner/saloon` — بيانات صالونه
- `PUT /api/owner/saloon/services` — تعديل الخدمات
- `PUT /api/owner/saloon/timeslots` — تعديل الأوقات
- `GET /api/owner/bookings` — مواعيده

### Public
- `GET /api/book/:slug` — بيانات الصالون للزبون
- `GET /api/book/:slug/booked?day=...` — الأوقات المحجوزة
- `POST /api/book/:slug` — تأكيد حجز جديد

---

## ملاحظات مهمة

- البيانات تُحفظ في ملف `db.json` في مجلد الباك إند
- التوكن صالح 7 أيام
- لما تنشر الموقع، غيّر `JWT_SECRET` في `server.js`
