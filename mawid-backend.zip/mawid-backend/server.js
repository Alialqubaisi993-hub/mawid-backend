const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 4000;
const JWT_SECRET = "mawid_secret_2024_change_in_production";
const DB_FILE = path.join(__dirname, "db.json");

app.use(cors());
app.use(express.json());

// ─── DB helpers ──────────────────────────────────────────────────────────────
function readDB() {
  if (!fs.existsSync(DB_FILE)) return getDefaultDB();
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}
function getDefaultDB() {
  const adminPass = bcrypt.hashSync("admin123", 10);
  return {
    users: [
      {
        id: "admin-1",
        name: "المدير",
        email: "admin@mawid.app",
        password: adminPass,
        role: "admin",
        createdAt: new Date().toISOString(),
      },
    ],
    saloons: [],
    bookings: [],
  };
}

// Initialize DB if not exists
if (!fs.existsSync(DB_FILE)) writeDB(getDefaultDB());

// ─── Middleware ───────────────────────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith("Bearer ")) return res.status(401).json({ error: "غير مصرح" });
  try {
    req.user = jwt.verify(auth.split(" ")[1], JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "توكن غير صالح" });
  }
}
function adminOnly(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "للمدير فقط" });
  next();
}
function ownerOnly(req, res, next) {
  if (!["admin", "owner"].includes(req.user.role)) return res.status(403).json({ error: "غير مصرح" });
  next();
}

// ─── AUTH ─────────────────────────────────────────────────────────────────────

// Login
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find((u) => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: "البريد أو كلمة المرور غلط" });

  const token = jwt.sign({ id: user.id, email: user.email, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: "7d" });

  // If owner, also get their saloon
  let saloon = null;
  if (user.role === "owner") {
    saloon = db.saloons.find((s) => s.ownerId === user.id) || null;
  }

  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role }, saloon });
});

// Register owner (public — pending approval)
app.post("/api/auth/register", (req, res) => {
  const { name, email, password, saloonName, phone, city } = req.body;
  if (!name || !email || !password || !saloonName || !phone)
    return res.status(400).json({ error: "جميع الحقول مطلوبة" });

  const db = readDB();
  if (db.users.find((u) => u.email === email))
    return res.status(400).json({ error: "البريد مسجل مسبقاً" });

  const userId = uuidv4();
  const saloonId = uuidv4();
  const hashedPass = bcrypt.hashSync(password, 10);

  db.users.push({
    id: userId,
    name,
    email,
    password: hashedPass,
    role: "owner",
    createdAt: new Date().toISOString(),
  });

  db.saloons.push({
    id: saloonId,
    ownerId: userId,
    name: saloonName,
    ownerName: name,
    phone,
    city: city || "",
    status: "pending", // pending | active | suspended
    plan: "free",
    services: [
      { id: uuidv4(), name: "قص شعر", duration: "30 دقيقة", price: "80" },
      { id: uuidv4(), name: "صبغة شعر", duration: "90 دقيقة", price: "200" },
      { id: uuidv4(), name: "تسريح وبلو", duration: "45 دقيقة", price: "120" },
    ],
    workDays: ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"],
    timeSlots: ["9:00 ص", "9:30 ص", "10:00 ص", "10:30 ص", "11:00 ص", "11:30 ص", "2:00 م", "2:30 م", "3:00 م", "4:00 م", "4:30 م", "5:00 م"],
    slug: saloonName.toLowerCase().replace(/\s+/g, "-") + "-" + saloonId.slice(0, 6),
    bookings: 0,
    createdAt: new Date().toISOString(),
  });

  writeDB(db);
  res.json({ success: true, message: "تم التسجيل، انتظر موافقة المدير" });
});

// ─── ADMIN ROUTES ─────────────────────────────────────────────────────────────

// Get all saloons
app.get("/api/admin/saloons", authMiddleware, adminOnly, (req, res) => {
  const db = readDB();
  res.json(db.saloons);
});

// Toggle saloon status
app.patch("/api/admin/saloons/:id/status", authMiddleware, adminOnly, (req, res) => {
  const { status } = req.body; // active | suspended | pending
  const db = readDB();
  const saloon = db.saloons.find((s) => s.id === req.params.id);
  if (!saloon) return res.status(404).json({ error: "الصالون غير موجود" });
  saloon.status = status;
  writeDB(db);
  res.json(saloon);
});

// Admin stats
app.get("/api/admin/stats", authMiddleware, adminOnly, (req, res) => {
  const db = readDB();
  res.json({
    total: db.saloons.length,
    active: db.saloons.filter((s) => s.status === "active").length,
    pending: db.saloons.filter((s) => s.status === "pending").length,
    suspended: db.saloons.filter((s) => s.status === "suspended").length,
    totalBookings: db.bookings.length,
  });
});

// ─── OWNER ROUTES ─────────────────────────────────────────────────────────────

// Get my saloon
app.get("/api/owner/saloon", authMiddleware, ownerOnly, (req, res) => {
  const db = readDB();
  const saloon = db.saloons.find((s) => s.ownerId === req.user.id);
  if (!saloon) return res.status(404).json({ error: "لا يوجد صالون مرتبط" });
  res.json(saloon);
});

// Update services
app.put("/api/owner/saloon/services", authMiddleware, ownerOnly, (req, res) => {
  const { services } = req.body;
  const db = readDB();
  const saloon = db.saloons.find((s) => s.ownerId === req.user.id);
  if (!saloon) return res.status(404).json({ error: "لا يوجد صالون" });
  saloon.services = services;
  writeDB(db);
  res.json(saloon);
});

// Update time slots
app.put("/api/owner/saloon/timeslots", authMiddleware, ownerOnly, (req, res) => {
  const { timeSlots, workDays } = req.body;
  const db = readDB();
  const saloon = db.saloons.find((s) => s.ownerId === req.user.id);
  if (!saloon) return res.status(404).json({ error: "لا يوجد صالون" });
  if (timeSlots) saloon.timeSlots = timeSlots;
  if (workDays) saloon.workDays = workDays;
  writeDB(db);
  res.json(saloon);
});

// Get my bookings
app.get("/api/owner/bookings", authMiddleware, ownerOnly, (req, res) => {
  const db = readDB();
  const saloon = db.saloons.find((s) => s.ownerId === req.user.id);
  if (!saloon) return res.status(404).json({ error: "لا يوجد صالون" });
  const bookings = db.bookings.filter((b) => b.saloonId === saloon.id);
  res.json(bookings);
});

// ─── PUBLIC BOOKING ROUTES ────────────────────────────────────────────────────

// Get saloon by slug (for clients)
app.get("/api/book/:slug", (req, res) => {
  const db = readDB();
  const saloon = db.saloons.find((s) => s.slug === req.params.slug && s.status === "active");
  if (!saloon) return res.status(404).json({ error: "الصالون غير موجود أو غير مفعّل" });
  // Return public info only
  const { ownerId, ...publicSaloon } = saloon;
  res.json(publicSaloon);
});

// Get booked slots for a saloon/day
app.get("/api/book/:slug/booked", (req, res) => {
  const { day } = req.query;
  const db = readDB();
  const saloon = db.saloons.find((s) => s.slug === req.params.slug);
  if (!saloon) return res.status(404).json({ error: "غير موجود" });
  const booked = db.bookings
    .filter((b) => b.saloonId === saloon.id && b.day === day && b.status !== "cancelled")
    .map((b) => b.time);
  res.json(booked);
});

// Create booking
app.post("/api/book/:slug", (req, res) => {
  const { name, phone, service, day, time } = req.body;
  if (!name || !phone || !service || !day || !time)
    return res.status(400).json({ error: "جميع الحقول مطلوبة" });

  const db = readDB();
  const saloon = db.saloons.find((s) => s.slug === req.params.slug && s.status === "active");
  if (!saloon) return res.status(404).json({ error: "الصالون غير موجود" });

  // Check if slot taken
  const taken = db.bookings.find((b) => b.saloonId === saloon.id && b.day === day && b.time === time && b.status !== "cancelled");
  if (taken) return res.status(409).json({ error: "هذا الوقت محجوز مسبقاً" });

  const booking = {
    id: uuidv4(),
    saloonId: saloon.id,
    saloonName: saloon.name,
    name,
    phone,
    service,
    day,
    time,
    status: "confirmed",
    createdAt: new Date().toISOString(),
  };

  db.bookings.push(booking);
  saloon.bookings = (saloon.bookings || 0) + 1;
  writeDB(db);
  res.json({ success: true, booking });
});

// ─── START ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => console.log(`✅ Mawid Backend running on http://localhost:${PORT}`));
